const { user1, user2 } = require('./08_users-1');
const hello = require('./06_hello');

hello(user1);
hello(user2);

const hello = (name) => {
  console.log(`${name}님, 안녕하세요?`);
};
module.exports = hello;

// 다른 풀이
// exports.hello = (name) => {
//   console.log(`${name}님, 안녕하세요?`);
// };

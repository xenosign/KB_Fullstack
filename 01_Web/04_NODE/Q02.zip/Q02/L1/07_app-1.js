const user = require('./05_user');
const hello = require('./06_hello');

console.log(user);
console.log(hello);
hello('이효석');

import { goodbye } from './12_greeting-1.mjs';

goodbye('이효석');

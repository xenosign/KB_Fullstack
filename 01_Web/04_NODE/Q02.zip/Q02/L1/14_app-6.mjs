import { hi, goodbye } from './12_greeting-1.mjs';

hi('이효석');
goodbye('이효석');

import goodbye from './11_goodbye-2.mjs';

goodbye();

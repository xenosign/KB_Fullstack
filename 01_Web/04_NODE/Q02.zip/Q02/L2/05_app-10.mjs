import say from './04_greeting-2.mjs';

say.hi('이효석');
say.goodbye('이효석');

import * as say from '../L1/12_greeting-1.mjs';

say.hi('이효석');
say.goodbye('이효석');

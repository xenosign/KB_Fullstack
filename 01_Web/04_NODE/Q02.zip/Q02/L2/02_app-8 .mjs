import { hi as hello, goodbye as bye } from '../L1/12_greeting-1.mjs';

hello('이효석');
bye('이효석');

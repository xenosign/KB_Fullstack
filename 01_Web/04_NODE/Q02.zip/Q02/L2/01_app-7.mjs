import { goodbye as bye } from '../L1/12_greeting-1.mjs';

bye('이효석');

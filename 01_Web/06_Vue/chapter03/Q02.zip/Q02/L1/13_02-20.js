import { add } from './12_02-19.js';

console.log(add(4));
